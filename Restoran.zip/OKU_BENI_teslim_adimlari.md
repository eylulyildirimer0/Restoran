# COME 381 — Ödev 1 + Ödev 2: dört ayrı senaryo

| Klasör | Senaryo | Tablolar | M:N ara tablo | Test sayısı |
|---|---|---|---|---|
| `1_online_kurs` | Online kurs platformu | 4 | `enrollment` (öğrenci–kurs) | 29 |
| `2_restoran` | Restoran sipariş sistemi | 5 | `order_item` (sipariş–ürün) | 32 |
| `3_veteriner` | Veteriner kliniği aşı takibi | 5 | `vaccination` (hayvan–aşı) | 33 |
| `4_futbol_ligi` | Amatör futbol ligi | 4 | `appearance` (oyuncu–maç) | 35 |

Her klasör, ödevin istediği repo yapısının birebir aynısı:

```
README.md              Ödev 1: senaryo + tasarım kararı (3-5 cümle)
AI_LOG.md              ## Ödev 1 ve ## Ödev 2 (D6 denemesi dahil)
docs/er.md             Mermaid ER diyagramı
sql/schema.sql         CREATE TABLE'lar
week-05/README.md      çalıştırma sırası, NULL testi, beklenmeyen sonuç
week-05/constraints.sql
week-05/violations.sql
week-05/violations_output.txt   (gerçek psql çıktısı, elle düzenlenmedi)
week-05/on_delete.md
week-05/seed.sql
week-05/algebra.md
week-05/algebra.sql
RAPOR.md               ödevin anlatımı (ödevde istenmiyor, istersen repoya koyma)
```

Hepsi PostgreSQL 16'da README'deki sırayla çalıştırıldı: `schema.sql` temiz veritabanında hatasız, her testte beklenen SQLSTATE ile gerçekleşen aynı, D4 ve D6 ne boş ne bütün tablo, D6'da "neredeyse" aday var ve eleniyor.

## Her kişi teslimden önce şunları yapmalı

1. **Senaryo kontrolü:** Ödev, Hafta 2'de açtığın Issue'daki senaryoyu kullanmanı istiyor. Issue'daki senaryo buradakinden farklıysa önce onu düzelt.
2. **Kendi bilgisayarında çalıştır** (çıktı sende de aynı çıkmalı):
   ```bash
   createdb come381
   psql -d come381 -f sql/schema.sql
   psql -d come381 -f week-05/constraints.sql
   psql -d come381 -f week-05/violations.sql > week-05/violations_output.txt 2>&1
   psql -d come381 -f week-05/seed.sql
   psql -d come381 -f week-05/algebra.sql
   ```
   Windows'ta her komuta `-U postgres` ekle. `violations_output.txt`'yi kendi makinende yeniden üretmek en dürüstü.
3. **AI_LOG Bölüm E:** Ödev, D6 sorusunu **senin** bir yapay zekaya sormanı ve prompt'u aynen yazmanı istiyor. AI_LOG'daki prompt ve sorgu bir örnek; kendin sorduğunda farklı bir cevap gelirse onu yapıştır ve kendi verinde çalıştırıp karşılaştır.
4. **`RAPOR.md`'deki** _(ad soyad)_ ve _(kullanıcı adı)_ yerlerini doldur.
5. **Mermaid'i GitHub'da aç:** `docs/er.md` push'tan sonra çizim olarak görünmeli.

## Repo ve commit'ler (commit geçmişi puanlanıyor, tek commit atma)

```bash
gh repo create come381-midterm-KULLANICIADI --private --add-readme --clone
cd come381-midterm-KULLANICIADI
git checkout -b week-05
# klasörün içeriğini buraya kopyala, sonra parça parça commit'le:

git add docs/er.md                 && git commit -m "Ödev 1: ER diyagramı"
git add sql/schema.sql             && git commit -m "Ödev 1: tablolar"
git add README.md                  && git commit -m "Ödev 1: senaryo ve tasarım kararı"
git add week-05/constraints.sql    && git commit -m "Ödev 2 A: constraint'ler"
git add week-05/violations.sql week-05/violations_output.txt && git commit -m "Ödev 2 B: ihlal testleri"
git add week-05/on_delete.md       && git commit -m "Ödev 2 C: silme politikası"
git add week-05/seed.sql week-05/algebra.sql week-05/algebra.md && git commit -m "Ödev 2 D: ilişkisel cebir"
git add AI_LOG.md                  && git commit -m "Ödev 2 E: yapay zeka günlüğü"
git add week-05/README.md          && git commit -m "Ödev 2: README"

git push -u origin week-05
gh pr create --base main --head week-05 --title "Ödev 1 + Ödev 2"
```

Settings → Collaborators'tan `gizemturker`'ı ekle, PR'a reviewer yap, PR açıklamasına ödevdeki kontrol listesini yapıştır. PR'ı merge etme.
