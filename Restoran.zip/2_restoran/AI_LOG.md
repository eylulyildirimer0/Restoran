# Yapay zeka kullanım günlüğü

## Ödev 1

- **Araç:** Claude (Anthropic)
- **Ne için:** Restoran senaryosundaki varlıkları belirlemek, `order` kelimesinin ayrılmış kelime olması sorununu çözmek (`customer_order`), sipariş–ürün M:N ilişkisi için ara tabloyu kurmak ve Mermaid diyagramını yazmak.
- **Kontrol:** `schema.sql` boş bir veritabanında çalıştırıldı, ERROR çıkmadı.

## Ödev 2

### D6 (division) denemesi

**1. Prompt (aynen):**

> PostgreSQL'de customer, customer_order(order_id, customer_id), order_item(order_id, item_id, quantity) ve menu_item(item_id, category_code, name) tablolarım var. Tatlı kategorisindeki ('TAT') bütün ürünleri sipariş etmiş müşterileri bulan SQL sorgusunu yazar mısın?

**Gelen sorgu, kendi verimde çalıştırınca:**

```sql
SELECT c.full_name
FROM customer c
JOIN customer_order o ON o.customer_id = c.customer_id
JOIN order_item oi    ON oi.order_id   = o.order_id
JOIN menu_item m      ON m.item_id     = oi.item_id
WHERE m.category_code = 'TAT'
GROUP BY c.customer_id, c.full_name
HAVING COUNT(*) = (SELECT COUNT(*) FROM menu_item WHERE category_code = 'TAT')
ORDER BY c.full_name;
```

Sonuç:

```text
   full_name   
---------------
 Emre Aydın
 Nazlı Er
 Seda Yıldırım
(3 rows)
```

**2. Benim D6 sorgumun sonucu:**

```text
 full_name  
------------
 Emre Aydın
 Nazlı Er
(2 rows)
```

Yapay zekanın sorgusu fazladan **Seda Yıldırım**'ı döndürdü.

**3. Hata nerede?** Sorgu tatlı kategorisini doğru filtreliyor ama `COUNT(*)` **satır** sayıyor, **farklı ürün** saymıyor. Seda Baklava'yı iki ayrı siparişte almış (sipariş 3 ve 8), bir de Sütlaç almış: 3 satır. Tatlı sayısı da 3 olduğu için seçiliyor, oysa Künefe'yi hiç sipariş etmemiş. Aynı (müşteri, ürün) çifti birden çok siparişte geçince bir satır iki kez sayılıyor. Düzeltme: `COUNT(DISTINCT m.item_id)`.

Hatanın gerçekten bundan kaynaklandığını görmek için Seda'nın tatlı satırlarına baktım:

```sql
SELECT o.order_id, m.name
FROM customer_order o
JOIN order_item oi ON oi.order_id = o.order_id
JOIN menu_item m   ON m.item_id   = oi.item_id
WHERE o.customer_id = 2 AND m.category_code = 'TAT'
ORDER BY o.order_id, m.name;
```

Sonuç:

```text
 order_id |  name   
----------+---------
        3 | Baklava
        3 | Sütlaç
        8 | Baklava
(3 rows)
```

**4. Veri:** Hatayı tetikleyen satırlar `seed.sql`'de: 8 numaralı sipariş (Seda'nın ikinci Baklava siparişi) bunun için eklendi.

### Ödevin diğer kısımları

- **Araç:** Claude (Anthropic)
- **Ne için:** `constraints.sql`, `violations.sql`, `seed.sql`, `algebra.sql` ve markdown dosyalarının taslakları.
- **Kontrol:** Dosyalar `week-05/README.md`'deki sırayla PostgreSQL 16'da çalıştırıldı; `violations_output.txt` doğrudan psql çıktısıdır ve her testte beklenen SQLSTATE ile gerçekleşen karşılaştırıldı.
