# COME 381 Vize Projesi: Restoran Sipariş Sistemi

Senaryom bir mahalle restoranının sipariş sistemi: müşteriler kayıt olup sipariş veriyor, her sipariş menüden bir ya da birkaç ürün içeriyor ve ürünler Başlangıç, Ana Yemek, Tatlı gibi kategorilere ayrılıyor. Sipariş ile ürün arasındaki M:N ilişkiyi `order_item` ara tablosuyla kurdum ve anahtarını `(order_id, item_id)` bileşik PK yaptım; aynı ürün bir siparişte ikinci satır olarak değil `quantity` artırılarak tutuluyor. Verdiğim önemli bir karar, `order_item`'a ayrıca `unit_price` koymak oldu: menüdeki fiyat zamanla değişse bile eski siparişin hangi fiyattan satıldığı kaybolmasın. Kategoriler için yapay bir id yerine `ANA`, `TAT` gibi üç harfli doğal bir anahtar kullandım, çünkü kod hem kısa hem kalıcı.

- ER diyagramı: [`docs/er.md`](docs/er.md)
- Şema: [`sql/schema.sql`](sql/schema.sql)
- Ödev 2: [`week-05/`](week-05/)
