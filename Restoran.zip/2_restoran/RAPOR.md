# COME 381 — Ödev 1 + Ödev 2 Raporu: Restoran Sipariş Sistemi

**Hazırlayan:** _(ad soyad)_ — **GitHub:** _(kullanıcı adı)_ — **Repo:** `come381-midterm-<kullanıcı adı>`, branch `week-05`

---

## Özet

Bu raporda, bir mahalle restoranının paket ve salon siparişlerini tutan beş tablolu bir PostgreSQL veritabanının tasarımını (Ödev 1) ve bu veritabanına eklenen iş kurallarını, kuralların testlerini, silme politikalarını ve ilişkisel cebir sorgularını (Ödev 2) anlatıyorum. Bütün SQL dosyaları temiz bir veritabanında hatasız çalışıyor; 32 ihlal testinin tamamı beklenen sonucu verdi.

## 1. Problem ve kapsam

Restoranın tutmak istediği bilgiler: kimin sipariş verdiği, siparişte hangi yemeklerden kaçar tane olduğu, siparişin hangi aşamada olduğu (hazırlanıyor / teslim edildi / iptal) ve menünün kategorilere göre düzeni. Ödeme, kurye ve stok bilgisi kapsam dışında bırakıldı.

## 2. Tasarım (Ödev 1)

**Tablolar:** `customer`, `menu_category`, `menu_item`, `customer_order`, `order_item`.

**İlişkiler:**

- `customer` 1 — N `customer_order`
- `menu_category` 1 — N `menu_item`
- `customer_order` M — N `menu_item`, ara tablo `order_item`

**Verdiğim üç karar:**

1. **Tablo adı `customer_order`.** `ORDER` SQL'de ayrılmış kelime; tabloyu `order` diye açmak her sorguda tırnak gerektirirdi.
2. **`order_item`'da bileşik PK `(order_id, item_id)`.** Aynı ürünü bir siparişte iki satır olarak tutmak yerine `quantity` alanını kullanıyorum. Böylece PK, "aynı siparişte aynı ürün iki kez yazılamaz" kuralını da kendiliğinden sağlıyor.
3. **`order_item.unit_price`.** Menü fiyatı değişebilir; eski siparişlerin ciro hesabı bozulmasın diye satış anındaki fiyatı kalemde saklıyorum.

Kategoriler için `category_code char(3)` doğal anahtarını kullandım (`ANA`, `TAT`, `ICK`...). Para alanları `numeric(7,2)`, sipariş zamanı `timestamp`, diğer anahtarlar identity.

## 3. İş kuralları ve constraint'ler (Bölüm A)

- **10 NOT NULL:** müşteri adı ve telefonu, kategori adı, ürünün kategorisi/adı/fiyatı, sipariş zamanı ve durumu, kalemin adedi ve birim fiyatı. `customer_order.customer_id` bilerek boş bırakılabilir (aşağıdaki SET NULL kararı yüzünden).
- **3 UNIQUE:** telefon, kategori adı ve çok sütunlu `uq_menu_item_category_name (category_code, name)`. Bu son kural "aynı kategoride aynı adda iki ürün olmaz" diyor ama farklı kategoride aynı ada izin veriyor.
- **4 CHECK:** fiyat > 0; adet 1–50 arası; durum yalnızca üç değerden biri; indirimli fiyat ≤ liste fiyatı.
- **4 isimli FOREIGN KEY**, her biri farklı silme politikasıyla.

## 4. Testler ve bulgular (Bölüm B)

`violations.sql` 32 test içeriyor: 10 NOT NULL, 4 UNIQUE/PK, 6 CHECK ihlali, 3 sınır testi (fiyat 0,01; adet tam 50; indirim = liste fiyatı), 4 "olmayan ebeveyn" testi, 3 "çocuğu olan ebeveyn" testi (silme ve **anahtar güncelleme**), 2 silme davranışı testi ve 1 NULL testi.

İki bulgu öne çıktı:

- **NULL ve CHECK:** İndirimi olmayan (`NULL`) ürün, `discount_price <= list_price` kuralına rağmen eklendi. SQL'in üç değerli mantığında `NULL <= 110` sonucu *unknown*'dır; CHECK yalnızca *false*'u reddeder.
- **Güncelleme de foreign key'e takılıyor:** Kategori kodunu `TAT`'tan `DES`'e çevirmek `23503` hatası verdi. Doğal anahtar seçmenin bedelini burada gördüm; ilerde `ON UPDATE CASCADE` eklemeyi düşünüyorum.

## 5. Silme politikaları (Bölüm C)

Dört foreign key için dört farklı politika kullandım:

- **CASCADE** (sipariş → kalem): kalem siparişin parçası, sipariş giderse kalemin anlamı kalmaz. Kanıt: 3 numaralı sipariş silinince `customer_order` 8'den 7'ye, `order_item` 15'ten 12'ye indi.
- **SET NULL** (müşteri → sipariş): KVKK gereği müşteri silinebilmeli ama satış kaydı kalmalı; sipariş anonimleşiyor.
- **NO ACTION** (ürün → kalem): satılmış ürün silinemez; menüden kaldırmak için `is_available = false`.
- **RESTRICT** (kategori → ürün): içi dolu kategori silinemez.

RESTRICT kontrolü hemen yapar ve ertelenemez; NO ACTION kontrolü ifadenin sonuna, `DEFERRABLE` ise transaction'ın sonuna bırakabilir.

## 6. İlişkisel cebir (Bölüm D)

`seed.sql`: 8 müşteri, 5 kategori, 12 ürün, 8 sipariş, 15 kalem.

| Soru | İşlem | Sonuç |
|---|---|---|
| D1: 300 TL üstü ürünler | σ, π | 3 ürün |
| D2: Ana yemek kalemleri (müşteri, yemek, durum) | ⋈ | 4 satır |
| D3: Hem ana yemek hem tatlı alanlar | ∩ | 2 müşteri |
| D4: Hiç sipariş vermeyenler | − (EXCEPT ve NOT EXISTS) | 2 müşteri, iki yol aynı |
| D5: Aynı semtteki müşteri çiftleri | ρ + self-join | 4 çift |
| D6: Bütün tatlıları almış müşteriler | ÷ | 2 müşteri |

D4 ayrıca ilişkisel hesapla yazıldı. D6'yı `GROUP BY ... HAVING COUNT(DISTINCT item_id) = (tatlı sayısı)` ile çözdüm. Bu senaryoda bir müşteri aynı tatlıyı birden çok siparişte alabildiği için `DISTINCT`, SQL'in "çanta" davranışını cebirin "küme" davranışına çeviren adım oldu.

## 7. Yapay zeka (Bölüm E)

Bir yapay zekadan aynı D6 sorgusunu istedim. Gelen sorgu kategoriyi doğru filtreliyordu ama `COUNT(*)` kullanıyordu. Seda Yıldırım Baklava'yı iki ayrı siparişte almış, Sütlaç'ı bir kez almış, Künefe'yi hiç almamış; yine de 3 tatlı satırı olduğu için sorgu onu "bütün tatlıları almış" sandı. Bu veriyi `seed.sql`'e bilerek koymuştum (8 numaralı sipariş). Ayrıntılar `AI_LOG.md`'de.

## 8. Değerlendirme

En çok öğrendiğim şey, kısa bir SQL sorgusunun doğru *görünmesiyle* doğru *olması* arasındaki fark oldu. Hem constraint'lerde hem division sorgusunda doğruluğu ancak bilerek bozmaya çalışarak görebildim. Ayrıca silme politikasının teknik değil iş kararı olduğunu, SET NULL seçimini KVKK gibi bir gerçek hayat gereksinimiyle gerekçelendirirken fark ettim.
