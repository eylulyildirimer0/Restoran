-- COME 381 - Ödev 1
-- Senaryo: Restoran sipariş sistemi (müşteri, menü, sipariş, sipariş kalemi)
-- Çalıştırma: psql -d come381_test -f sql/schema.sql

DROP TABLE IF EXISTS order_item, customer_order, menu_item, menu_category, customer CASCADE;

-- Restorana kayıtlı müşteri (paket servis / sadakat programı)
CREATE TABLE customer (
    customer_id    integer GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    full_name      varchar(100),
    phone          varchar(20),
    district       varchar(50),
    registered_on  date DEFAULT CURRENT_DATE
);

-- Menü kategorisi. Anahtar olarak kısa, anlamlı bir kod kullanıyoruz (ANA, TAT, ...)
CREATE TABLE menu_category (
    category_code  char(3) PRIMARY KEY,
    name           varchar(50)
);

-- Menüdeki ürün; her ürün bir kategoriye aittir (1:N)
CREATE TABLE menu_item (
    item_id         integer GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    category_code   char(3) REFERENCES menu_category (category_code),
    name            varchar(100),
    list_price      numeric(7,2),
    discount_price  numeric(7,2),
    is_available    boolean DEFAULT true
);

-- Sipariş. "order" SQL'de ayrılmış kelime olduğu için tablo adı customer_order
CREATE TABLE customer_order (
    order_id     integer GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    customer_id  integer REFERENCES customer (customer_id),
    ordered_at   timestamp,
    status       varchar(20)
);

-- Sipariş <-> menü ürünü arasındaki M:N ilişkinin ara tablosu.
-- Bir siparişte aynı ürün bir satırda tutulur, adedi quantity'de.
CREATE TABLE order_item (
    order_id    integer REFERENCES customer_order (order_id),
    item_id     integer REFERENCES menu_item (item_id),
    quantity    integer,
    unit_price  numeric(7,2),
    PRIMARY KEY (order_id, item_id)
);
