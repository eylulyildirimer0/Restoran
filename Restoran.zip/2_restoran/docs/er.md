# ER diyagramı: Restoran sipariş sistemi

- Bir **müşteri** 0..N **sipariş** verir. Hesabını silen müşterinin siparişleri anonim olarak kalır; bu yüzden bir siparişin müşterisi 0..1.
- Bir **sipariş** birden çok **menü ürünü** içerir, bir ürün birçok siparişte geçer: M:N. Bu ilişki `ORDER_ITEM` ara tablosuyla kuruldu; adet ve sipariş anındaki birim fiyat ilişkinin nitelikleri.
- Her **ürün** tam olarak bir **kategoriye** aittir; bir kategoride 0..N ürün olur.

```mermaid
erDiagram
    CUSTOMER       |o--o{ CUSTOMER_ORDER : "places"
    CUSTOMER_ORDER ||--|{ ORDER_ITEM : "contains"
    MENU_ITEM      ||--o{ ORDER_ITEM : "appears in"
    MENU_CATEGORY  ||--o{ MENU_ITEM : "groups"

    CUSTOMER {
        int customer_id PK
        string full_name
        string phone UK
        string district
        date registered_on
    }
    MENU_CATEGORY {
        char category_code PK
        string name UK
    }
    MENU_ITEM {
        int item_id PK
        char category_code FK
        string name
        numeric list_price
        numeric discount_price
        boolean is_available
    }
    CUSTOMER_ORDER {
        int order_id PK
        int customer_id FK
        timestamp ordered_at
        string status
    }
    ORDER_ITEM {
        int order_id PK, FK
        int item_id PK, FK
        int quantity
        numeric unit_price
    }
```

| İlişki | Kardinalite |
|---|---|
| CUSTOMER – CUSTOMER_ORDER | Müşterinin 0..N siparişi; siparişin 0..1 müşterisi (anonim sipariş olabilir) |
| CUSTOMER_ORDER – ORDER_ITEM | Siparişin 1..N kalemi; kalem tam olarak bir siparişe ait |
| MENU_ITEM – ORDER_ITEM | Ürün 0..N kalemde geçer; kalem tam olarak bir ürünü gösterir |
| MENU_CATEGORY – MENU_ITEM | Kategoride 0..N ürün; ürün tam olarak bir kategoride |

Not: "Siparişin en az bir kalemi olmalı" (1..N) kuralı diyagramda var ama tablolar arası bir kural olduğu için şemada zorlanmıyor (bkz. `week-05/README.md`).
