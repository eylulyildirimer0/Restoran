# Bölüm D: İlişkisel cebir ve hesap

Kısaltılmış şema:

- `customer(customer_id, full_name, phone, district, registered_on)`
- `menu_category(category_code, name)`
- `menu_item(item_id, category_code, name, list_price, discount_price, is_available)`
- `customer_order(order_id, customer_id, ordered_at, status)`
- `order_item(order_id, item_id, quantity, unit_price)`

Veri (`seed.sql`): 8 müşteri, 5 kategori, 12 ürün (3'ü tatlı), 8 sipariş, 15 sipariş kalemi. Cebirde uzun join zincirini tekrar tekrar yazmamak için bir ara ilişki tanımlıyorum:

**S** ← customer ⋈<sub>customer.customer_id = customer_order.customer_id</sub> customer_order ⋈ order_item ⋈ menu_item

(`order_item` ile `customer_order` `order_id` üzerinden, `menu_item` ile `order_item` `item_id` üzerinden doğal join.)

---

## D1 — σ ve π

**Soru:** Liste fiyatı 300 TL'den yüksek menü ürünlerinin adı ve fiyatı.

**Cebir:** π<sub>name, list_price</sub> ( σ<sub>list_price > 300</sub> (menu_item) )

```sql
SELECT name, list_price
FROM menu_item
WHERE list_price > 300
ORDER BY list_price;
```

```text
     name      | list_price 
---------------+------------
 Adana Kebap   |     320.00
 İskender      |     360.00
 Izgara Levrek |     410.00
(3 rows)
```

**DISTINCT?** Gerekmez: `(name, list_price)` tekrar etmiyor; `uq_menu_item_category_name` sayesinde aynı kategoride aynı adlı iki ürün zaten olamıyor.

---

## D2 — ⋈ join

**Soru:** Ana yemek içeren her sipariş kaleminde müşteri adı, yemek adı ve sipariş durumu.

**Cebir:** π<sub>full_name, name, status</sub> ( σ<sub>category_code = 'ANA'</sub> (S) )

```sql
SELECT c.full_name, m.name AS yemek, o.status
FROM customer c
JOIN customer_order o ON o.customer_id = c.customer_id
JOIN order_item oi    ON oi.order_id   = o.order_id
JOIN menu_item m      ON m.item_id     = oi.item_id
WHERE m.category_code = 'ANA'
ORDER BY c.full_name;
```

```text
   full_name   |     yemek     |  status   
---------------+---------------+-----------
 Emre Aydın    | Adana Kebap   | delivered
 Oğuz Kaya     | İskender      | delivered
 Seda Yıldırım | Mantı         | delivered
 Tolga Şimşek  | Izgara Levrek | cancelled
(4 rows)
```

**DISTINCT?** Gerekmez. Soru "her kalem" diyor; bir müşteri aynı yemeği iki farklı siparişte alsaydı iki satır görmek istenen sonuç olurdu. Cebir burada iki satırı tek satıra indirirdi; bu, küme ile çanta farkının işe yaradığı bir yer.

---

## D3 — ∩ intersection

**Soru:** Hem bir ana yemek hem bir tatlı sipariş etmiş müşteriler.

**Cebir:** π<sub>customer_id, full_name</sub> ( σ<sub>category_code = 'ANA'</sub> (S) ) ∩ π<sub>customer_id, full_name</sub> ( σ<sub>category_code = 'TAT'</sub> (S) )

```sql
SELECT c.customer_id, c.full_name
FROM customer c
JOIN customer_order o ON o.customer_id = c.customer_id
JOIN order_item oi    ON oi.order_id   = o.order_id
JOIN menu_item m      ON m.item_id     = oi.item_id
WHERE m.category_code = 'ANA'
INTERSECT
SELECT c.customer_id, c.full_name
FROM customer c
JOIN customer_order o ON o.customer_id = c.customer_id
JOIN order_item oi    ON oi.order_id   = o.order_id
JOIN menu_item m      ON m.item_id     = oi.item_id
WHERE m.category_code = 'TAT'
ORDER BY customer_id;
```

```text
 customer_id |   full_name   
-------------+---------------
           1 | Emre Aydın
           2 | Seda Yıldırım
(2 rows)
```

**DISTINCT?** Gerekmez; `INTERSECT` küme kesişimi yapar ve tekrarları atar. Seda üç ayrı tatlı satırına sahip ama sonuçta bir kez görünüyor. Burada `customer_id`'yi de projekte ettim: sadece adla kesişim alsaydım, aynı adı taşıyan iki farklı müşteri birbirine karışabilirdi.

---

## D4 — − difference

**Soru:** Hiç sipariş vermemiş müşteriler.

**Cebir:** π<sub>customer_id, full_name</sub> (customer) − π<sub>customer_id, full_name</sub> ( customer ⋈ customer_order )

**1. yol, EXCEPT:**

```sql
SELECT customer_id, full_name
FROM customer
EXCEPT
SELECT c.customer_id, c.full_name
FROM customer c
JOIN customer_order o ON o.customer_id = c.customer_id
ORDER BY customer_id;
```

```text
 customer_id |  full_name  
-------------+-------------
           7 | Volkan Acar
           8 | Melis Ateş
(2 rows)
```

**2. yol, NOT EXISTS:**

```sql
SELECT c.customer_id, c.full_name
FROM customer c
WHERE NOT EXISTS (
    SELECT 1 FROM customer_order o WHERE o.customer_id = c.customer_id
)
ORDER BY c.customer_id;
```

```text
 customer_id |  full_name  
-------------+-------------
           7 | Volkan Acar
           8 | Melis Ateş
(2 rows)
```

İki yol da aynı iki müşteriyi döndürüyor.

**İlişkisel hesap (TRC):**

{ c.customer_id, c.full_name | customer(c) ∧ ¬∃o ( customer_order(o) ∧ o.customer_id = c.customer_id ) }

**DISTINCT?** Gerekmez. `EXCEPT` tekrarları kendisi atar; NOT EXISTS sürümü her müşteriyi en fazla bir kez döndürür.

---

## D5 — ρ ile self-join

**Soru:** Aynı semtte oturan farklı müşteri çiftleri.

**Cebir:**

ρ<sub>a</sub>(customer), ρ<sub>b</sub>(customer)

π<sub>a.full_name, b.full_name, a.district</sub> ( a ⋈<sub>a.district = b.district ∧ a.customer_id < b.customer_id</sub> b )

```sql
SELECT a.full_name AS musteri_1, b.full_name AS musteri_2, a.district
FROM customer a
JOIN customer b ON a.district = b.district
               AND a.customer_id < b.customer_id
ORDER BY a.district, a.customer_id, b.customer_id;
```

```text
   musteri_1   |   musteri_2   | district 
---------------+---------------+----------
 Oğuz Kaya     | Tolga Şimşek  | Beşiktaş
 Emre Aydın    | Seda Yıldırım | Kadıköy
 Emre Aydın    | Pınar Güneş   | Kadıköy
 Seda Yıldırım | Pınar Güneş   | Kadıköy
(4 rows)
```

**DISTINCT?** Gerekmez; `a.customer_id < b.customer_id` her çifti tek yönde ve bir kez üretiyor, kişinin kendisiyle eşleşmesini de engelliyor.

---

## D6 — ÷ division

**Soru:** Tatlı kategorisindeki **tüm** ürünleri en az bir kez sipariş etmiş müşteriler.

**Cebir:**

A ← π<sub>customer_id, item_id</sub> ( customer_order ⋈ order_item )

B ← π<sub>item_id</sub> ( σ<sub>category_code = 'TAT'</sub> (menu_item) )

π<sub>full_name</sub> ( (A ÷ B) ⋈ customer )

```sql
SELECT c.full_name
FROM customer c
JOIN customer_order o ON o.customer_id = c.customer_id
JOIN order_item oi    ON oi.order_id   = o.order_id
JOIN menu_item m      ON m.item_id     = oi.item_id
WHERE m.category_code = 'TAT'
GROUP BY c.customer_id, c.full_name
HAVING COUNT(DISTINCT m.item_id) = (SELECT COUNT(*) FROM menu_item WHERE category_code = 'TAT')
ORDER BY c.full_name;
```

```text
 full_name  
------------
 Emre Aydın
 Nazlı Er
(2 rows)
```

**Neden GROUP BY + HAVING?** Bu senaryoda bir müşteri aynı tatlıyı farklı siparişlerde tekrar tekrar alabiliyor; sayım yöntemini seçip `COUNT(DISTINCT m.item_id)` yazarak bu tekrarı açıkça ele almak istedim, çünkü sorgu okununca "farklı tatlı sayısı = tatlı sayısı" mantığı hemen görülüyor.

"Neredeyse" aday Seda Yıldırım: Baklava'yı iki ayrı siparişte, Sütlaç'ı bir kez almış, Künefe'yi hiç almamış. Tatlı satırı sayısı 3, ama farklı tatlı sayısı 2; doğru sorgu onu eliyor.

**DISTINCT?** Sonuç kümesinde gerekmez (`GROUP BY customer_id` her müşteriyi bir kez döndürür) ama `COUNT` içinde **gerekli**. Cebirdeki A bir küme olduğu için (Seda, Baklava) çifti A'da bir kez bulunur; SQL'de join bunu iki satır olarak üretir. `COUNT(DISTINCT ...)` SQL'in çantasını cebirin kümesine çeviren adım.
