-- COME 381 - Ödev 2, Bölüm D: ilişkisel cebir sorularının SQL karşılıkları
-- seed.sql'den sonra çalıştır. Cebir ifadeleri algebra.md'de.

-- @D1
-- Liste fiyatı 300 TL'den yüksek menü ürünlerinin adı ve fiyatı
SELECT name, list_price
FROM menu_item
WHERE list_price > 300
ORDER BY list_price;

-- @D2
-- Ana yemek içeren her sipariş kaleminde müşteri adı, yemek adı ve sipariş durumu
SELECT c.full_name, m.name AS yemek, o.status
FROM customer c
JOIN customer_order o ON o.customer_id = c.customer_id
JOIN order_item oi    ON oi.order_id   = o.order_id
JOIN menu_item m      ON m.item_id     = oi.item_id
WHERE m.category_code = 'ANA'
ORDER BY c.full_name;

-- @D3
-- Hem bir ana yemek hem de bir tatlı sipariş etmiş müşteriler (INTERSECT)
SELECT c.customer_id, c.full_name
FROM customer c
JOIN customer_order o ON o.customer_id = c.customer_id
JOIN order_item oi    ON oi.order_id   = o.order_id
JOIN menu_item m      ON m.item_id     = oi.item_id
WHERE m.category_code = 'ANA'
INTERSECT
SELECT c.customer_id, c.full_name
FROM customer c
JOIN customer_order o ON o.customer_id = c.customer_id
JOIN order_item oi    ON oi.order_id   = o.order_id
JOIN menu_item m      ON m.item_id     = oi.item_id
WHERE m.category_code = 'TAT'
ORDER BY customer_id;

-- @D4a
-- Hiç sipariş vermemiş müşteriler (EXCEPT)
SELECT customer_id, full_name
FROM customer
EXCEPT
SELECT c.customer_id, c.full_name
FROM customer c
JOIN customer_order o ON o.customer_id = c.customer_id
ORDER BY customer_id;

-- @D4b
-- Hiç sipariş vermemiş müşteriler (NOT EXISTS)
SELECT c.customer_id, c.full_name
FROM customer c
WHERE NOT EXISTS (
    SELECT 1 FROM customer_order o WHERE o.customer_id = c.customer_id
)
ORDER BY c.customer_id;

-- @D5
-- Aynı semtte oturan farklı müşteri çiftleri
SELECT a.full_name AS musteri_1, b.full_name AS musteri_2, a.district
FROM customer a
JOIN customer b ON a.district = b.district
               AND a.customer_id < b.customer_id
ORDER BY a.district, a.customer_id, b.customer_id;

-- @D6
-- Tatlı kategorisindeki TÜM ürünleri (en az bir kez) sipariş etmiş müşteriler
-- (GROUP BY ... HAVING COUNT(DISTINCT ...) = ...)
SELECT c.full_name
FROM customer c
JOIN customer_order o ON o.customer_id = c.customer_id
JOIN order_item oi    ON oi.order_id   = o.order_id
JOIN menu_item m      ON m.item_id     = oi.item_id
WHERE m.category_code = 'TAT'
GROUP BY c.customer_id, c.full_name
HAVING COUNT(DISTINCT m.item_id) = (SELECT COUNT(*) FROM menu_item WHERE category_code = 'TAT')
ORDER BY c.full_name;
