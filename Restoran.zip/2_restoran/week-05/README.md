# Hafta 5 — Ödev 2

## 1. Çalıştırma sırası

```bash
psql -d come381 -f sql/schema.sql
psql -d come381 -f week-05/constraints.sql
psql -d come381 -f week-05/violations.sql
psql -d come381 -f week-05/seed.sql
psql -d come381 -f week-05/algebra.sql
```

Repo kökünden çalıştırılır. `violations.sql` tabloları boşaltarak başladığı için `seed.sql` ondan sonra gelmeli. Windows'ta komutlara `-U postgres` ekle.

## 2. NULL testi (T32)

`menu_item.discount_price` için `CHECK (discount_price <= list_price)` var ama sütun `NOT NULL` değil. T32'de Sütlaç'ı indirimsiz (`discount_price = NULL`) ekledim ve kabul edildi. Çıktıdaki `kural_sonucu` sütunu boş görünüyor: `NULL <= 110` true ya da false değil, **unknown**. PostgreSQL bir CHECK'i yalnızca **false** dönerse reddeder, unknown'ı geçirir. Bu senaryoda doğru davranış bu (indirim olmayabilir), ama demek ki "boş olamaz" kuralı CHECK ile değil `NOT NULL` ile yazılmalı.

## 3. Beklediğimden farklı çıkan şey

T29'da kategorinin kodunu değiştirmeye çalıştım (`TAT` → `DES`) ve `23503` aldım. Silme politikasını düşünürken güncellemeyi hiç düşünmemiştim; `ON UPDATE` yazmadığım için varsayılan `NO ACTION` devreye girdi ve çocuk satırları olan bir anahtar değiştirilemedi. Doğal anahtar seçmenin bedeli bu: anahtar anlamlı olduğu için bir gün değişmek isteyebilir. Ya `ON UPDATE CASCADE` eklenmeli ya da değişmeyecek bir yapay anahtar kullanılmalı.

## Notlar

- CHECK ile yazamadığım, birden çok tabloya yayılan kurallar:
  - "Her siparişin en az bir kalemi olmalı." (`customer_order` ve `order_item` birlikte)
  - "`is_available = false` olan bir ürün yeni bir siparişe eklenemez." (`menu_item` ve `order_item` birlikte)
  - Bunlar Hafta 8'de trigger ile yazılacak.
- T14, çok sütunlu PK'nın (`order_item_pkey`) da bir UNIQUE gibi çalıştığını gösteriyor.
- Bütün testlerde beklenen ve gerçekleşen sonuç aynı çıktı.
