-- COME 381 - Ödev 2, Bölüm A
-- schema.sql'den SONRA çalışır.

------------------------------------------------------------
-- NOT NULL
------------------------------------------------------------

-- Müşteriyi tanıyabilmek ve siparişi teslim edebilmek için adı ve telefonu şart.
ALTER TABLE customer ALTER COLUMN full_name SET NOT NULL;
ALTER TABLE customer ALTER COLUMN phone     SET NOT NULL;

-- Her kategorinin menüde görünecek bir adı olmalı.
ALTER TABLE menu_category ALTER COLUMN name SET NOT NULL;

-- Menüdeki her ürünün kategorisi, adı ve liste fiyatı olmalı.
ALTER TABLE menu_item ALTER COLUMN category_code SET NOT NULL;
ALTER TABLE menu_item ALTER COLUMN name          SET NOT NULL;
ALTER TABLE menu_item ALTER COLUMN list_price    SET NOT NULL;

-- Her siparişin ne zaman verildiği ve hangi aşamada olduğu bilinmeli.
-- (customer_id bilerek NOT NULL değil: müşteri hesabını silince sipariş anonim kalır.)
ALTER TABLE customer_order ALTER COLUMN ordered_at SET NOT NULL;
ALTER TABLE customer_order ALTER COLUMN status     SET NOT NULL;

-- Her sipariş kaleminin adedi ve o anki satış fiyatı kayıtlı olmalı.
ALTER TABLE order_item ALTER COLUMN quantity   SET NOT NULL;
ALTER TABLE order_item ALTER COLUMN unit_price SET NOT NULL;

------------------------------------------------------------
-- UNIQUE
------------------------------------------------------------

-- Bir telefon numarası yalnızca bir müşteri hesabına ait olabilir.
ALTER TABLE customer
    ADD CONSTRAINT uq_customer_phone UNIQUE (phone);

-- Aynı adla iki kategori açılamaz.
ALTER TABLE menu_category
    ADD CONSTRAINT uq_menu_category_name UNIQUE (name);

-- Aynı kategoride aynı adı taşıyan iki ürün olamaz (farklı kategoride olabilir).
ALTER TABLE menu_item
    ADD CONSTRAINT uq_menu_item_category_name UNIQUE (category_code, name);

------------------------------------------------------------
-- CHECK
------------------------------------------------------------

-- Bir ürünün liste fiyatı sıfırdan büyük olmalı.
ALTER TABLE menu_item
    ADD CONSTRAINT chk_menu_item_list_price_positive CHECK (list_price > 0);

-- Bir sipariş kaleminde en az 1, en fazla 50 adet olabilir.
ALTER TABLE order_item
    ADD CONSTRAINT chk_order_item_quantity_range CHECK (quantity BETWEEN 1 AND 50);

-- Sipariş yalnızca hazırlanıyor, teslim edildi ya da iptal durumunda olabilir.
ALTER TABLE customer_order
    ADD CONSTRAINT chk_customer_order_status
        CHECK (status IN ('preparing', 'delivered', 'cancelled'));

-- İndirimli fiyat, liste fiyatından yüksek olamaz.
ALTER TABLE menu_item
    ADD CONSTRAINT chk_menu_item_price_order CHECK (discount_price <= list_price);

------------------------------------------------------------
-- FOREIGN KEY (Ödev 1'deki otomatik adlı FK'leri kaldırıp isimli ekliyoruz)
------------------------------------------------------------

ALTER TABLE menu_item      DROP CONSTRAINT menu_item_category_code_fkey;
ALTER TABLE customer_order DROP CONSTRAINT customer_order_customer_id_fkey;
ALTER TABLE order_item     DROP CONSTRAINT order_item_order_id_fkey;
ALTER TABLE order_item     DROP CONSTRAINT order_item_item_id_fkey;

-- Her ürün var olan bir kategoride olmalı; içinde ürün bulunan kategori silinemez.
ALTER TABLE menu_item
    ADD CONSTRAINT fk_menu_item_category FOREIGN KEY (category_code)
        REFERENCES menu_category (category_code) ON DELETE RESTRICT;

-- Sipariş var olan bir müşteriye ait olmalı; müşteri silinirse sipariş kalır ama anonimleşir.
ALTER TABLE customer_order
    ADD CONSTRAINT fk_customer_order_customer FOREIGN KEY (customer_id)
        REFERENCES customer (customer_id) ON DELETE SET NULL;

-- Kalem var olan bir siparişe ait olmalı; sipariş silinirse kalemleri de silinir.
ALTER TABLE order_item
    ADD CONSTRAINT fk_order_item_customer_order FOREIGN KEY (order_id)
        REFERENCES customer_order (order_id) ON DELETE CASCADE;

-- Kalem var olan bir menü ürününü göstermeli; geçmişte satılmış bir ürün silinemez.
ALTER TABLE order_item
    ADD CONSTRAINT fk_order_item_menu_item FOREIGN KEY (item_id)
        REFERENCES menu_item (item_id) ON DELETE NO ACTION;
