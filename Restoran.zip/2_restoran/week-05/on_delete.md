# Bölüm C: Silme politikası

| Foreign key | Ebeveyn → çocuk | Seçimin | Neden | Diğer seçenek neden olmadı |
|---|---|---|---|---|
| `fk_order_item_customer_order` | `customer_order` → `order_item` | `CASCADE` | Sipariş kalemi siparişin parçasıdır; siparişi olmayan bir "2 adet Baklava" satırının anlamı yok. Hatalı açılmış bir sipariş silindiğinde kalemleri de gitmeli. | `RESTRICT` ile hatalı bir siparişi silmek için önce kalemlerini tek tek silmek gerekirdi. |
| `fk_customer_order_customer` | `customer` → `customer_order` | `SET NULL` | Müşteri hesabını kapatırsa (KVKK'da silme hakkı) kişisel verisi gitmeli, ama siparişler restoranın ciro ve stok kaydıdır, kalmalı. Sipariş anonim olur. `customer_order.customer_id` bu yüzden `NOT NULL` değil. | `CASCADE` geçmiş satış kayıtlarını yok ederdi; `RESTRICT` ise müşterinin hesabını silmesini imkânsız kılardı. |
| `fk_order_item_menu_item` | `menu_item` → `order_item` | `NO ACTION` | Geçmişte satılmış bir ürün silinemez, yoksa eski siparişlerde ne satıldığı kaybolur. Ürün menüden kalkacaksa `is_available = false` yapılır. | `CASCADE` bir ürünü silince geçmiş siparişlerin kalemlerini de silerdi ve ciro raporu sessizce değişirdi. |
| `fk_menu_item_category` | `menu_category` → `menu_item` | `RESTRICT` | İçinde ürün olan bir kategori silinirse ürünler kategorisiz kalır. Önce ürünler başka kategoriye taşınmalı. | `SET NULL` kullanamazdık çünkü `menu_item.category_code` `NOT NULL`; `CASCADE` ise bir kategoriyle birlikte bütün ürünleri silerdi. |

Kullanılan politikalar: `CASCADE`, `SET NULL`, `NO ACTION`, `RESTRICT` (dört farklı politika).

## CASCADE kanıtı

`seed.sql` yüklü veritabanında Seda'nın 3 numaralı siparişini (3 kalemi var) siliyorum:

```text
SELECT (SELECT count(*) FROM customer_order) AS siparis_sayisi,
       (SELECT count(*) FROM order_item)     AS kalem_sayisi;
 siparis_sayisi | kalem_sayisi 
----------------+--------------
              8 |           15
(1 row)

DELETE FROM customer_order WHERE order_id = 3;
DELETE 1
SELECT (SELECT count(*) FROM customer_order) AS siparis_sayisi,
       (SELECT count(*) FROM order_item)     AS kalem_sayisi;
 siparis_sayisi | kalem_sayisi 
----------------+--------------
              7 |           12
(1 row)
```

`customer_order` 8 → 7, `order_item` 15 → 12: siparişin üç kalemi onunla birlikte silindi.

## RESTRICT ile NO ACTION farkı

`RESTRICT` ihlali satır silinir silinmez kontrol eder ve ertelenemez; `NO ACTION` ise kontrolü ifadenin sonunda yapar ve constraint `DEFERRABLE` tanımlanmışsa transaction'ın sonuna kadar erteleyebilir (ertelenmemişse ikisi pratikte aynı davranır).
