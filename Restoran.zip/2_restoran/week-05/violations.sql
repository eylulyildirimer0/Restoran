\set VERBOSITY verbose
-- COME 381 - Ödev 2, Bölüm B: ihlal testleri
-- Biçim: -- Tnn | hedef constraint | Beklenen: SQLSTATE ya da OK

------------------------------------------------------------
-- Hazırlık
------------------------------------------------------------
TRUNCATE order_item, customer_order, menu_item, menu_category, customer RESTART IDENTITY CASCADE;

INSERT INTO menu_category (category_code, name) VALUES
  ('ANA', 'Ana Yemek'),
  ('TAT', 'Tatlı');

INSERT INTO customer (full_name, phone, district) VALUES
  ('Emre Aydın', '05551110001', 'Kadıköy'),   -- 1
  ('Seda Yıldırım', '05551110002', 'Kadıköy'); -- 2

INSERT INTO menu_item (category_code, name, list_price, discount_price) VALUES
  ('ANA', 'Adana Kebap', 320, 290),  -- 1
  ('TAT', 'Baklava',     160, NULL); -- 2

INSERT INTO customer_order (customer_id, ordered_at, status) VALUES
  (1, '2026-10-01 19:30', 'delivered');  -- 1

INSERT INTO order_item (order_id, item_id, quantity, unit_price) VALUES
  (1, 1, 2, 290);

------------------------------------------------------------
-- NOT NULL
------------------------------------------------------------

-- T01 | customer.full_name NOT NULL | Beklenen: 23502
INSERT INTO customer (full_name, phone) VALUES (NULL, '05551110009');

-- T02 | customer.phone NOT NULL | Beklenen: 23502
INSERT INTO customer (full_name, phone) VALUES ('Telefonsuz Müşteri', NULL);

-- T03 | menu_category.name NOT NULL | Beklenen: 23502
INSERT INTO menu_category (category_code, name) VALUES ('ICK', NULL);

-- T04 | menu_item.category_code NOT NULL | Beklenen: 23502
INSERT INTO menu_item (category_code, name, list_price) VALUES (NULL, 'Ayran', 40);

-- T05 | menu_item.name NOT NULL | Beklenen: 23502
INSERT INTO menu_item (category_code, name, list_price) VALUES ('ANA', NULL, 250);

-- T06 | menu_item.list_price NOT NULL | Beklenen: 23502
INSERT INTO menu_item (category_code, name, list_price) VALUES ('ANA', 'Mantı', NULL);

-- T07 | customer_order.ordered_at NOT NULL | Beklenen: 23502
INSERT INTO customer_order (customer_id, ordered_at, status) VALUES (2, NULL, 'preparing');

-- T08 | customer_order.status NOT NULL | Beklenen: 23502
INSERT INTO customer_order (customer_id, ordered_at, status) VALUES (2, '2026-10-02 12:00', NULL);

-- T09 | order_item.quantity NOT NULL | Beklenen: 23502
INSERT INTO order_item (order_id, item_id, quantity, unit_price) VALUES (1, 2, NULL, 160);

-- T10 | order_item.unit_price NOT NULL | Beklenen: 23502
INSERT INTO order_item (order_id, item_id, quantity, unit_price) VALUES (1, 2, 1, NULL);

------------------------------------------------------------
-- UNIQUE / PRIMARY KEY
------------------------------------------------------------

-- T11 | uq_customer_phone | Beklenen: 23505
INSERT INTO customer (full_name, phone) VALUES ('Emre Aydın (yeni hesap)', '05551110001');

-- T12 | uq_menu_category_name | Beklenen: 23505
INSERT INTO menu_category (category_code, name) VALUES ('ANY', 'Ana Yemek');

-- T13 | uq_menu_item_category_name | Beklenen: 23505
INSERT INTO menu_item (category_code, name, list_price) VALUES ('TAT', 'Baklava', 175);

-- T14 | order_item_pkey (aynı siparişte aynı ürün ikinci satır) | Beklenen: 23505
INSERT INTO order_item (order_id, item_id, quantity, unit_price) VALUES (1, 1, 1, 290);

------------------------------------------------------------
-- CHECK
------------------------------------------------------------

-- T15 | chk_menu_item_list_price_positive | Beklenen: 23514
INSERT INTO menu_item (category_code, name, list_price) VALUES ('TAT', 'Bedava Lokum', 0);

-- T16 | chk_menu_item_list_price_positive | Beklenen: OK (sınır: en küçük pozitif fiyat)
INSERT INTO menu_item (category_code, name, list_price) VALUES ('TAT', 'Tanıtım Lokumu', 0.01);

-- T17 | chk_order_item_quantity_range | Beklenen: 23514
INSERT INTO order_item (order_id, item_id, quantity, unit_price) VALUES (1, 2, 0, 160);

-- T18 | chk_order_item_quantity_range | Beklenen: 23514
INSERT INTO order_item (order_id, item_id, quantity, unit_price) VALUES (1, 2, 51, 160);

-- T19 | chk_order_item_quantity_range | Beklenen: OK (sınır: üst sınır 50 adet)
INSERT INTO order_item (order_id, item_id, quantity, unit_price) VALUES (1, 2, 50, 160);

-- T20 | chk_customer_order_status | Beklenen: 23514
INSERT INTO customer_order (customer_id, ordered_at, status) VALUES (2, '2026-10-02 12:00', 'on_the_way');

-- T21 | chk_menu_item_price_order | Beklenen: 23514
INSERT INTO menu_item (category_code, name, list_price, discount_price)
VALUES ('ANA', 'Ters Fiyatlı İskender', 360, 400);

-- T22 | chk_menu_item_price_order | Beklenen: OK (sınır: indirimli fiyat = liste fiyatı)
INSERT INTO menu_item (category_code, name, list_price, discount_price)
VALUES ('ANA', 'İskender', 360, 360);

------------------------------------------------------------
-- FOREIGN KEY: 1. yön, olmayan ebeveyne bağlanmak
------------------------------------------------------------

-- T23 | fk_menu_item_category | Beklenen: 23503
INSERT INTO menu_item (category_code, name, list_price) VALUES ('XXX', 'Gizemli Yemek', 100);

-- T24 | fk_customer_order_customer | Beklenen: 23503
INSERT INTO customer_order (customer_id, ordered_at, status) VALUES (9999, '2026-10-03 20:00', 'preparing');

-- T25 | fk_order_item_customer_order | Beklenen: 23503
INSERT INTO order_item (order_id, item_id, quantity, unit_price) VALUES (9999, 1, 1, 320);

-- T26 | fk_order_item_menu_item | Beklenen: 23503
INSERT INTO order_item (order_id, item_id, quantity, unit_price) VALUES (1, 9999, 1, 100);

------------------------------------------------------------
-- FOREIGN KEY: 2. yön, çocuğu olan ebeveyni silmek ya da anahtarını değiştirmek
------------------------------------------------------------

-- T27 | fk_order_item_menu_item (NO ACTION) | Beklenen: 23503
DELETE FROM menu_item WHERE name = 'Adana Kebap';

-- T28 | fk_menu_item_category (RESTRICT) | Beklenen: 23503
DELETE FROM menu_category WHERE category_code = 'ANA';

-- T29 | fk_menu_item_category (anahtarı değiştirmek, ON UPDATE NO ACTION) | Beklenen: 23503
UPDATE menu_category SET category_code = 'DES' WHERE category_code = 'TAT';

-- T30 | fk_customer_order_customer (SET NULL) | Beklenen: OK (sipariş kalır, müşterisi boşalır)
DELETE FROM customer WHERE phone = '05551110001';
SELECT order_id, customer_id, status FROM customer_order WHERE order_id = 1;

-- T31 | fk_order_item_customer_order (CASCADE) | Beklenen: OK (kalemler siparişle silinir)
SELECT count(*) AS kalem_once FROM order_item WHERE order_id = 1;
DELETE FROM customer_order WHERE order_id = 1;
SELECT count(*) AS kalem_sonra FROM order_item WHERE order_id = 1;

------------------------------------------------------------
-- NULL testi: CHECK'i olan ama NOT NULL olmayan sütun
------------------------------------------------------------

-- T32 | chk_menu_item_price_order + NULL discount_price | Beklenen: OK
INSERT INTO menu_item (category_code, name, list_price, discount_price)
VALUES ('TAT', 'Sütlaç', 110, NULL);
SELECT name, list_price, discount_price, discount_price <= list_price AS kural_sonucu
FROM menu_item WHERE name = 'Sütlaç';
