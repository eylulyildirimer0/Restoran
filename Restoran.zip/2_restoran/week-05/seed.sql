-- COME 381 - Ödev 2, Bölüm D için küçük veri seti
-- violations.sql'den SONRA çalışır. Tabloları boşaltır, id'ler 1'den başlar.

TRUNCATE order_item, customer_order, menu_item, menu_category, customer RESTART IDENTITY CASCADE;

INSERT INTO menu_category (category_code, name) VALUES
  ('BAS', 'Başlangıç'),
  ('ANA', 'Ana Yemek'),
  ('TAT', 'Tatlı'),
  ('ICK', 'İçecek'),
  ('SAL', 'Salata');

-- 8 müşteri
INSERT INTO customer (full_name, phone, district, registered_on) VALUES
  ('Emre Aydın',     '05551110001', 'Kadıköy',  '2025-03-01'),  -- 1
  ('Seda Yıldırım',  '05551110002', 'Kadıköy',  '2025-04-12'),  -- 2 (D6 "neredeyse" adayı)
  ('Oğuz Kaya',      '05551110003', 'Beşiktaş', '2025-05-20'),  -- 3
  ('Nazlı Er',       '05551110004', 'Üsküdar',  '2025-06-02'),  -- 4
  ('Tolga Şimşek',   '05551110005', 'Beşiktaş', '2025-08-15'),  -- 5
  ('Pınar Güneş',    '05551110006', 'Kadıköy',  '2025-11-30'),  -- 6
  ('Volkan Acar',    '05551110007', 'Şişli',    '2026-01-05'),  -- 7 (siparişi yok)
  ('Melis Ateş',     '05551110008', 'Ataşehir', '2026-02-14');  -- 8 (siparişi yok)

-- 12 menü ürünü: 3 tanesi Tatlı
INSERT INTO menu_item (category_code, name, list_price, discount_price, is_available) VALUES
  ('BAS', 'Mercimek Çorbası',   85.00, NULL,   true),   -- 1
  ('BAS', 'Humus',             110.00, NULL,   true),   -- 2
  ('ANA', 'Adana Kebap',       320.00, 290.00, true),   -- 3
  ('ANA', 'İskender',          360.00, NULL,   true),   -- 4
  ('ANA', 'Mantı',             240.00, 220.00, true),   -- 5
  ('ANA', 'Izgara Levrek',     410.00, 380.00, false),  -- 6
  ('TAT', 'Baklava',           160.00, NULL,   true),   -- 7
  ('TAT', 'Künefe',            180.00, 165.00, true),   -- 8
  ('TAT', 'Sütlaç',            110.00, NULL,   true),   -- 9
  ('ICK', 'Ayran',              40.00, NULL,   true),   -- 10
  ('ICK', 'Türk Kahvesi',       70.00, NULL,   true),   -- 11
  ('SAL', 'Çoban Salata',       95.00, NULL,   true);   -- 12

-- 8 sipariş
INSERT INTO customer_order (customer_id, ordered_at, status) VALUES
  (1, '2026-09-01 19:10', 'delivered'),   -- 1
  (1, '2026-09-08 20:45', 'delivered'),   -- 2
  (2, '2026-09-03 13:00', 'delivered'),   -- 3
  (3, '2026-09-05 21:15', 'delivered'),   -- 4
  (4, '2026-09-10 15:30', 'delivered'),   -- 5
  (5, '2026-09-12 19:00', 'cancelled'),   -- 6
  (6, '2026-09-14 12:20', 'preparing'),   -- 7
  (2, '2026-09-20 22:05', 'delivered');   -- 8  (Seda baklavayı ikinci kez alıyor)

-- 15 sipariş kalemi
INSERT INTO order_item (order_id, item_id, quantity, unit_price) VALUES
  (1, 3, 1, 290.00),   -- Emre: Adana
  (1, 7, 2, 160.00),   -- Emre: Baklava
  (2, 8, 1, 165.00),   -- Emre: Künefe
  (2, 9, 1, 110.00),   -- Emre: Sütlaç   -> Emre 3 tatlının hepsini almış
  (3, 5, 2, 220.00),   -- Seda: Mantı
  (3, 7, 1, 160.00),   -- Seda: Baklava
  (3, 9, 2, 110.00),   -- Seda: Sütlaç
  (8, 7, 3, 160.00),   -- Seda: Baklava (yine) -> 3 tatlı satırı ama Künefe yok
  (4, 4, 1, 360.00),   -- Oğuz: İskender
  (5, 7, 1, 160.00),   -- Nazlı: Baklava
  (5, 8, 1, 165.00),   -- Nazlı: Künefe
  (5, 9, 1, 110.00),   -- Nazlı: Sütlaç  -> Nazlı 3 tatlının hepsini almış
  (6, 6, 1, 380.00),   -- Tolga: Levrek (iptal edilen sipariş)
  (7, 1, 2,  85.00),   -- Pınar: Çorba
  (7, 10, 2, 40.00);   -- Pınar: Ayran
